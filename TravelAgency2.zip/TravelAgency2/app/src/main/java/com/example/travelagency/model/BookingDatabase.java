package com.example.travelagency.model;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class BookingDatabase {

    /* Instance fields */
    private final DatabaseReference bookingDatabase;

    /* Constructors */
    public BookingDatabase() {
        this.bookingDatabase = FirebaseDatabase.getInstance().getReference("bookings");
    }

    /* Main Features */

    public void addBooking(
            String destination, String date, int participants, String description,
            Callback<String> callback
    ) {
        // Generate a unique key for the booking reservation
        String key = this.bookingDatabase.push().getKey();

        if (key == null) {
            callback.onResult(null);
            return;
        }

        // Create a HashMap to store the booking details
        HashMap<String, Object> value = new HashMap<>();
        value.put("destination", destination);
        value.put("date", date);
        value.put("participants", participants);
        value.put("description", description);

        // Save the booking data to Firebase
        this.bookingDatabase.child(key).setValue(value).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                callback.onResult(key); // Return the booking ID if successful
            } else {
                callback.onResult(null); // Return null if operation fails
            }
        });
    }

    public void getBooking(
            ArrayList<String> keys,
            Callback<HashMap<String, HashMap<String, Object>>> callback
    ) {
        if (keys == null || keys.isEmpty()) {
            callback.onResult(null);
            return;
        }

        HashMap<String, HashMap<String, Object>> result = new HashMap<>();
        int[] pendingRequests = {keys.size()}; // Counter to track pending Firebase requests
        boolean[] hasFailed = {false}; // To track if any request fails

        for (String bookingId : keys) {
            DatabaseReference ref = this.bookingDatabase.child(bookingId);

            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        HashMap<String, Object> bookingDetails = new HashMap<>();
                        for (DataSnapshot detailSnapshot : dataSnapshot.getChildren()) {
                            String key = detailSnapshot.getKey();
                            Object value = detailSnapshot.getValue();
                            if (key != null && value != null) {
                                bookingDetails.put(key, value);
                            }
                        }
                        // Add the booking details to the result
                        result.put(bookingId, bookingDetails);
                    }
                    synchronized (pendingRequests) {
                        pendingRequests[0]--;
                        if (pendingRequests[0] == 0) {
                            // All requests completed
                            callback.onResult(hasFailed[0] ? null : result);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    synchronized (pendingRequests) {
                        pendingRequests[0]--;
                        hasFailed[0] = true; // Mark failure
                        if (pendingRequests[0] == 0) {
                            // All requests completed
                            callback.onResult(null);
                        }
                    }
                }
            });
        }
    }

    /* Callbacks */
    public interface Callback<T> {
        void onResult(T result);
    }
}
