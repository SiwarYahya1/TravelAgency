package com.example.travelagency.view;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.travelagency.R;

public class ConfirmationActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        // Initialize views
        TextView confirmationMessage = findViewById(R.id.confirmation_message);

        // Get reservation details from intent
        String tripName = getIntent().getStringExtra("TRIP_NAME");
        String participantName = getIntent().getStringExtra("PARTICIPANT_NAME");

        // Display confirmation message
        confirmationMessage.setText("Reservation confirmed for " + participantName + " on trip " + tripName);
    }
}
