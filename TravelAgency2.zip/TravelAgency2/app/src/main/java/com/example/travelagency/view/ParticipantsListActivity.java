package com.example.travelagency.view;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.travelagency.R;

import java.util.ArrayList;

public class ParticipantsListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participants_list);

        // Initialize views
        ListView participantsListView = findViewById(R.id.participants_list_view);

        // Get participants list from intent
        ArrayList<String> participants = getIntent().getStringArrayListExtra("PARTICIPANTS_LIST");

        // Set up the list view
        assert participants != null;
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, participants);
        participantsListView.setAdapter(adapter);
    }
}
