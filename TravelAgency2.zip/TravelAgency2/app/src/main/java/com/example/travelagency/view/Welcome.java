package com.example.travelagency.view;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.travelagency.R;

public class Welcome extends AppCompatActivity {
    private static final int DELAY_MILLIS = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        new Handler().postDelayed(() -> {
            Intent intent = new Intent(this, UserSignIn1.class);
            startActivity(intent);
            finish();
        }, DELAY_MILLIS);
    }
}
