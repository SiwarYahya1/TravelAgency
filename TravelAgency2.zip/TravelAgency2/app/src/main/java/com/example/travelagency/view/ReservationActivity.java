package com.example.travelagency.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.travelagency.R;
import com.example.travelagency.model.DatabaseManager;

public class ReservationActivity extends AppCompatActivity {

    private EditText tripIdInput;
    private EditText userIdInput;
    private EditText reservationDateInput;
    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        // Initialize views
        tripIdInput = findViewById(R.id.trip_id_input);
        userIdInput = findViewById(R.id.user_id_input);
        reservationDateInput = findViewById(R.id.reservation_date_input);
        Button reserveButton = findViewById(R.id.btn_reserve);

        // Initialize database manager
        dbManager = new DatabaseManager(this);
        dbManager.open();

        // Set click listener for reserve button
        reserveButton.setOnClickListener(v -> handleReservation());
    }

    private void handleReservation() {
        long tripId = Long.parseLong(tripIdInput.getText().toString());
        long userId = Long.parseLong(userIdInput.getText().toString());
        String reservationDate = reservationDateInput.getText().toString();

        // Insert new reservation into the database
        long reservationId = dbManager.insertReservation(userId, tripId, reservationDate);
        if (reservationId > 0) {
            Toast.makeText(ReservationActivity.this, "Reservation created successfully", Toast.LENGTH_SHORT).show();
            // Navigate to the confirmation activity
            Intent intent = new Intent(ReservationActivity.this, ConfirmationActivity.class);
            intent.putExtra("TRIP_NAME", "Trip Name"); // Replace with actual trip name
            intent.putExtra("PARTICIPANT_NAME", "Participant Name"); // Replace with actual participant name
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(ReservationActivity.this, "Failed to create reservation", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbManager.close();
    }
}
