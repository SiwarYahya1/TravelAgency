package com.example.travelagency.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.travelagency.R;
import com.example.travelagency.model.DatabaseManager;
import com.example.travelagency.viewmodel.MainViewModel;

public class UserSignIn extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_signin);

        // Initialize views
        usernameInput = findViewById(R.id.text_username_input);
        passwordInput = findViewById(R.id.text_password_input);
        Button loginButton = findViewById(R.id.btn_login);
        Button createAccountButton = findViewById(R.id.btn_create_account);
        Button quitButton = findViewById(R.id.quit);

        // Initialize database manager
        dbManager = new DatabaseManager(this);
        dbManager.open();

        // Set click listeners for buttons
        loginButton.setOnClickListener(v -> handleLogin());

        createAccountButton.setOnClickListener(v -> handleCreateAccount());

        quitButton.setOnClickListener(v -> handleQuit());
    }

    private void handleLogin() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        // Implement login logic here
        if (validateLogin(username, password)) {
            // Login successful
            Intent intent = new Intent(UserSignIn.this, MainViewModel.class);
            startActivity(intent);
            finish();
        } else {
            // Login failed
            Toast.makeText(UserSignIn.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateLogin(String username, String password) {
        // Implement validation logic here
        // For example, check login information in the database
        return "admin".equals(username) && "password".equals(password); // Example
    }

    private void handleCreateAccount() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        // Insert new user into the database
        long userId = dbManager.insertUser(username, "email@example.com", password);
        if (userId > 0) {
            Toast.makeText(UserSignIn.this, "Account created successfully", Toast.LENGTH_SHORT).show();
            // Navigate to the main activity after account creation
            Intent intent = new Intent(UserSignIn.this, MainViewModel.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(UserSignIn.this, "Failed to create account", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleQuit() {
        // Implement logout logic here
        finishAffinity();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbManager.close();
    }
}
