package com.example.travelagency.model;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DatabaseManager {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public DatabaseManager(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    // Insert a new user
    public long insertUser(String name, String email, String password) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USER_NAME, name);
        values.put(DatabaseHelper.COLUMN_USER_EMAIL, email);
        values.put(DatabaseHelper.COLUMN_USER_PASSWORD, password);
        return database.insert(DatabaseHelper.TABLE_USERS, null, values);
    }

    // Insert a new trip
    public long insertTrip(String name, String destination, String date, int seats) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TRIP_NAME, name);
        values.put(DatabaseHelper.COLUMN_TRIP_DESTINATION, destination);
        values.put(DatabaseHelper.COLUMN_TRIP_DATE, date);
        values.put(DatabaseHelper.COLUMN_TRIP_SEATS, seats);
        return database.insert(DatabaseHelper.TABLE_TRIPS, null, values);
    }

    // Insert a new reservation
    public long insertReservation(long userId, long tripId, String date) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_RESERVATION_USER_ID, userId);
        values.put(DatabaseHelper.COLUMN_RESERVATION_TRIP_ID, tripId);
        values.put(DatabaseHelper.COLUMN_RESERVATION_DATE, date);
        return database.insert(DatabaseHelper.TABLE_RESERVATIONS, null, values);
    }

    // Get all users
    @SuppressLint("Range")
    public ArrayList<String> getAllUsers() {
        ArrayList<String> users = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.COLUMN_USER_NAME}, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                users.add(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_USER_NAME)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return users;
    }

    // Get all trips
    @SuppressLint("Range")
    public ArrayList<String> getAllTrips() {
        ArrayList<String> trips = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_TRIPS,
                new String[]{DatabaseHelper.COLUMN_TRIP_NAME}, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do trips.add(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TRIP_NAME)));
            while (cursor.moveToNext());
        }
        cursor.close();
        return trips;
    }

    // Get all reservations for a trip
    @SuppressLint("Range")
    public ArrayList<String> getReservationsForTrip(long tripId) {
        ArrayList<String> reservations = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_RESERVATIONS,
                new String[]{DatabaseHelper.COLUMN_RESERVATION_USER_ID},
                DatabaseHelper.COLUMN_RESERVATION_TRIP_ID + " = ?",
                new String[]{String.valueOf(tripId)}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                reservations.add(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_RESERVATION_USER_ID)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return reservations;
    }

    // Get frequent users
    @SuppressLint("Range")
    public ArrayList<String> getFrequentUsers() {
        ArrayList<String> frequentUsers = new ArrayList<>();
        String query = "SELECT " + DatabaseHelper.COLUMN_USER_NAME +
                " FROM " + DatabaseHelper.TABLE_USERS +
                " GROUP BY " + DatabaseHelper.COLUMN_USER_NAME +
                " HAVING COUNT(" + DatabaseHelper.COLUMN_USER_NAME + ") > 1";
        Cursor cursor = database.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                frequentUsers.add(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_USER_NAME)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return frequentUsers;
    }
}
