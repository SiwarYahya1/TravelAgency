package com.example.travelagency.model;



import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "travel_agency.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_TRIPS = "trips";
    public static final String TABLE_RESERVATIONS = "reservations";

    // Users table columns
    private static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USER_NAME = "user_name";
    public static final String COLUMN_USER_EMAIL = "user_email";
    public static final String COLUMN_USER_PASSWORD = "user_password";

    // Trips table columns
    private static final String COLUMN_TRIP_ID = "trip_id";
    public static final String COLUMN_TRIP_NAME = "trip_name";
    public static final String COLUMN_TRIP_DESTINATION = "trip_destination";
    public static final String COLUMN_TRIP_DATE = "trip_date";
    public static final String COLUMN_TRIP_SEATS = "trip_seats";

    // Reservations table columns
    private static final String COLUMN_RESERVATION_ID = "reservation_id";
    public static final String COLUMN_RESERVATION_USER_ID = "reservation_user_id";
    public static final String COLUMN_RESERVATION_TRIP_ID = "reservation_trip_id";
    public static final String COLUMN_RESERVATION_DATE = "reservation_date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS +
                "(" + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USER_NAME + " TEXT," +
                COLUMN_USER_EMAIL + " TEXT," +
                COLUMN_USER_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        // Create trips table
        String CREATE_TRIPS_TABLE = "CREATE TABLE " + TABLE_TRIPS +
                "(" + COLUMN_TRIP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_TRIP_NAME + " TEXT," +
                COLUMN_TRIP_DESTINATION + " TEXT," +
                COLUMN_TRIP_DATE + " TEXT," +
                COLUMN_TRIP_SEATS + " INTEGER)";
        db.execSQL(CREATE_TRIPS_TABLE);

        // Create reservations table
        String CREATE_RESERVATIONS_TABLE = "CREATE TABLE " + TABLE_RESERVATIONS +
                "(" + COLUMN_RESERVATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_RESERVATION_USER_ID + " INTEGER," +
                COLUMN_RESERVATION_TRIP_ID + " INTEGER," +
                COLUMN_RESERVATION_DATE + " TEXT)";
        db.execSQL(CREATE_RESERVATIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRIPS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS);
        onCreate(db);
    }
}
