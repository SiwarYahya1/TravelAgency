package com.example.travelagency.viewmodel;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {

    public void userSignUp(String username, String password, OnSignUpCallback callback) {
        // Logique d'inscription de l'utilisateur
        // Pour cet exemple, nous allons simuler une inscription réussie
        boolean success = !username.isEmpty() && !password.isEmpty();
        callback.onResult(success);
    }

    public void userSignIn(String trim, String trim1, Object o) {
    }

    public void getNonCollaborator(Object o) {
    }

    public interface OnSignUpCallback {
        void onResult(boolean success);
    }
}
