package com.example.travelagency.view;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.travelagency.R;

import java.util.ArrayList;

public class HomeLog extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_log);

        // Initialize views
        ListView logListView = findViewById(R.id.log_list_view);

        // Initialize log entries
        ArrayList<String> logEntries = new ArrayList<>();
        logEntries.add("Log Entry 1: User signed in");
        logEntries.add("Log Entry 2: User created a trip");
        logEntries.add("Log Entry 3: User booked a trip");

        // Set up the list view
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, logEntries);
        logListView.setAdapter(adapter);
    }
}
