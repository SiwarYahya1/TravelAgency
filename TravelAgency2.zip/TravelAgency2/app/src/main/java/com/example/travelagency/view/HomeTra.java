package com.example.travelagency.view;

import android.app.Activity;

public class HomeTra extends Activity {
}
