package com.example.travelagency.view;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.travelagency.R;

import java.util.ArrayList;

public class FrequentUsersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frequent_users);

        // Initialize views
        ListView frequentUsersListView = findViewById(R.id.frequent_users_list_view);

        // Get frequent users list from intent
        ArrayList<String> frequentUsers = getIntent().getStringArrayListExtra("FREQUENT_USERS_LIST");

        // Set up the list view
        assert frequentUsers != null;
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, frequentUsers);
        frequentUsersListView.setAdapter(adapter);
    }
}
