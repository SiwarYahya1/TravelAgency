package com.example.travelagency.model;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;


public class UserDatabase {

    /* Instance fields */

    private final DatabaseReference userDatabase;
    private String usernameCurr;

    /* Constructors */

    public UserDatabase() {
        this.userDatabase = FirebaseDatabase.getInstance().getReference("user");
    }

    /* Main Features */

    public void userSignUp(
            String username, String password,
            Callback<Boolean> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(username);
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    callback.onResult(false);
                } else {
                    HashMap<String, String> value = new HashMap<>();
                    value.put("username", username);
                    value.put("password", password);
                    userDatabase.child(username).setValue(value);
                    callback.onResult(true);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    public void userSignIn(
            String username, String password,
            Callback<Boolean> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(username);
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String passwordStored = dataSnapshot.child("password").getValue(String.class);
                if (dataSnapshot.exists() && password.equals(passwordStored)) {
                    usernameCurr = username;
                    callback.onResult(true);
                } else {
                    callback.onResult(false);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    public void addNote(
            String note,
            Callback<Boolean> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(this.usernameCurr).child("note");
        ref.setValue(note).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                callback.onResult(true); // Successfully added the note
            } else {
                callback.onResult(false); // Failed to add the note
            }
        });
    }

    public void getNote(
            Callback<HashMap<String, String>> callback
    ) {
        // Fetch the current user's collaborator list
        this.getCollaborator(collaborator -> {
            ArrayList<String> usersToFetch;
            if (collaborator == null) {
                usersToFetch = new ArrayList<>();
            } else {
                usersToFetch = new ArrayList<>(collaborator);
            }
            usersToFetch.add(this.usernameCurr); // Include current user

            // Create a map to store notes
            HashMap<String, String> notesMap = new HashMap<>();
            int[] pendingRequests = {usersToFetch.size()};
            boolean[] hasFailed = {false};

            for (String user : usersToFetch) {
                DatabaseReference ref = this.userDatabase.child(user).child("note");
                ref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        synchronized (pendingRequests) {
                            if (dataSnapshot.exists()) {
                                String note = dataSnapshot.getValue(String.class);
                                // Add note or empty string
                                notesMap.put(user, note != null ? note : "");
                            } else {
                                notesMap.put(user, ""); // No note found, add empty string
                            }

                            pendingRequests[0]--;
                            if (pendingRequests[0] == 0) {
                                callback.onResult(hasFailed[0] ? null : notesMap);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        synchronized (pendingRequests) {
                            hasFailed[0] = true;
                            pendingRequests[0]--;
                            if (pendingRequests[0] == 0) {
                                callback.onResult(null);
                            }
                        }
                    }
                });
            }
        });
    }

    public void addCollaborator(
            String username,
            Callback<Boolean> callback
    ) {
        this.getCollaborator(collaborator -> {
            // Prepare a list of users to update
            ArrayList<String> usersToUpdate;
            if (collaborator == null) {
                usersToUpdate = new ArrayList<>();
            } else {
                usersToUpdate = new ArrayList<>(collaborator);
            }
            usersToUpdate.add(username);
            usersToUpdate.add(this.usernameCurr);

            // Track total updates (collaborators + destination copy)
            int[] pendingUpdates = {usersToUpdate.size() + 3};
            boolean[] hasFailed = {false};

            // Update "destination" for the new collaborator
            this.getDestination(destinations -> {
                DatabaseReference destRef = this.userDatabase.child(username).child("destination");
                destRef.setValue(destinations).addOnCompleteListener(task -> {
                    synchronized (pendingUpdates) {
                        if (!task.isSuccessful()) {
                            hasFailed[0] = true;
                        }
                        pendingUpdates[0]--;
                        if (pendingUpdates[0] == 0) {
                            callback.onResult(!hasFailed[0]);
                        }
                    }
                });
            });

            // Update "dining" for the new collaborator
            this.getDining(dining -> {
                DatabaseReference diningRef = this.userDatabase.child(username).child("dining");
                diningRef.setValue(dining).addOnCompleteListener(task -> {
                    synchronized (pendingUpdates) {
                        if (!task.isSuccessful()) {
                            hasFailed[0] = true;
                        }
                        pendingUpdates[0]--;
                        if (pendingUpdates[0] == 0) {
                            callback.onResult(!hasFailed[0]);
                        }
                    }
                });
            });

            // Update "accommodation" for the new collaborator
            this.getAccommodation(accommodation -> {
                DatabaseReference ref = this.userDatabase.child(username).child("accommodation");
                ref.setValue(accommodation).addOnCompleteListener(task -> {
                    synchronized (pendingUpdates) {
                        if (!task.isSuccessful()) {
                            hasFailed[0] = true;
                        }
                        pendingUpdates[0]--;
                        if (pendingUpdates[0] == 0) {
                            callback.onResult(!hasFailed[0]);
                        }
                    }
                });
            });

            // Update "collaborator" for all users in the list
            for (String user : usersToUpdate) {
                // Create a unique collaborator list for each user
                ArrayList<String> temp = new ArrayList<>(usersToUpdate);
                temp.remove(user); // Remove the user themselves

                DatabaseReference ref = this.userDatabase.child(user).child("collaborator");
                ref.setValue(temp).addOnCompleteListener(task -> {
                    synchronized (pendingUpdates) {
                        if (!task.isSuccessful()) {
                            hasFailed[0] = true;
                        }
                        pendingUpdates[0]--;
                        if (pendingUpdates[0] == 0) {
                            callback.onResult(!hasFailed[0]);
                        }
                    }
                });
            }
        });
    }

    public void getCollaborator(
            Callback<ArrayList<String>> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(this.usernameCurr).child("collaborator");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    callback.onResult(null);
                    return;
                }

                ArrayList<String> collaborator = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String user = snapshot.getValue(String.class);
                    if (user != null) {
                        collaborator.add(user);
                    }
                }
                callback.onResult(collaborator); // Return the list of shared users
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(null); // Return null on error
            }
        });
    }

    public void getNonCollaborator(
            Callback<ArrayList<String>> callback
    ) {
        // Fetch the current user's "contributor" list
        this.getCollaborator(contributors -> {
            // Fetch all users from the database
            this.userDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    ArrayList<String> userList = new ArrayList<>();
                    // Iterate through all users in the database
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String user = userSnapshot.getKey();
                        // Exclude the current user and users in the "contributor" list
                        if (user != null && !user.equals(usernameCurr)
                                && (contributors == null || !contributors.contains(user))) {
                            userList.add(user);
                        }
                    }
                    callback.onResult(userList); // Return the filtered user list
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    callback.onResult(null); // Return null in case of an error
                }
            });
        });
    }

    public void addDestination(
            String key,
            Callback<Boolean> callback
    ) {
        this.getCollaborator(collaborator -> {
            // Prepare a list of users to update
            ArrayList<String> usersToUpdate;
            if (collaborator == null) {
                usersToUpdate = new ArrayList<>();
            } else {
                usersToUpdate = new ArrayList<>(collaborator);
            }
            usersToUpdate.add(this.usernameCurr);

            // Update destinations for all users in the list
            int[] pendingUpdates = {usersToUpdate.size()};
            boolean[] hasFailed = {false};
            for (String username : usersToUpdate) {
                addDestination(key, username, success -> {
                    synchronized (pendingUpdates) {
                        if (!success) {
                            hasFailed[0] = true; // Mark as failed if any update fails
                        }
                        pendingUpdates[0]--;
                        // If all updates are done
                        if (pendingUpdates[0] == 0) {
                            callback.onResult(!hasFailed[0]); // Success if no failures occurred
                        }
                    }
                });
            }
        });
    }

    private void addDestination(
            String key, String username,
            Callback<Boolean> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(username).child("destination");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> value = new ArrayList<>();

                if (dataSnapshot.exists()) {
                    // Parse the raw data into a list
                    for (DataSnapshot child : dataSnapshot.getChildren()) {
                        String destinationKey = child.getValue(String.class);
                        if (destinationKey != null) {
                            value.add(destinationKey);
                        }
                    }
                }

                // Check if the key is already in the list
                if (!value.contains(key)) {
                    value.add(key); // Add the new key if it's not already in the list
                }

                // Update the destinations list in Firebase
                ref.setValue(value).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onResult(true); // Success
                    } else {
                        callback.onResult(false); // Failure
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    public void getDestination(
            Callback<ArrayList<String>> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(this.usernameCurr).child("destination");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    callback.onResult(null);
                    return;
                }

                ArrayList<String> destinations = new ArrayList<>();
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    String destinationId = child.getValue(String.class);
                    if (destinationId != null) {
                        destinations.add(destinationId);
                    }
                }
                callback.onResult(destinations);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(null);
            }
        });
    }

    public void setVacation(
            String startDate, String endDate, String duration,
            Callback<Boolean> callback
    ) {
        DatabaseReference refer = this.userDatabase.child(this.usernameCurr).child("vacation");
        refer.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                HashMap<String, String> vacationData = new HashMap<>();
                vacationData.put("startDate", startDate);
                vacationData.put("endDate", endDate);
                vacationData.put("duration", duration);
                refer.setValue(vacationData);
                callback.onResult(true);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    public void getVacation(
            Callback<HashMap<String, String>> callback
    ) {
        DatabaseReference refer = this.userDatabase.child(this.usernameCurr).child("vacation");
        refer.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Prepare a HashMap to store the vacation data
                    HashMap<String, String> vacationData = new HashMap<>();
                    // Extract startDate, endDate, and duration from the snapshot
                    for (DataSnapshot child : dataSnapshot.getChildren()) {
                        String key = child.getKey();
                        String value = child.getValue(String.class);
                        if (key != null && value != null) {
                            vacationData.put(key, value);
                        }
                    }
                    // Pass the result to the callback
                    callback.onResult(vacationData);
                } else {
                    // If no vacation data exists, return an empty HashMap
                    callback.onResult(null);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(null);
            }
        });
    }

    public void addDining(
            String key,
            Callback<Boolean> callback
    ) {
        this.getCollaborator(collaborator -> {
            // Prepare a list of users to update
            ArrayList<String> usersToUpdate;
            if (collaborator == null) {
                usersToUpdate = new ArrayList<>();
            } else {
                usersToUpdate = new ArrayList<>(collaborator);
            }
            usersToUpdate.add(this.usernameCurr);

            // Update dining list for all users in the list
            int[] pendingUpdates = {usersToUpdate.size()};
            boolean[] hasFailed = {false};
            for (String username : usersToUpdate) {
                addDining(key, username, success -> {
                    synchronized (pendingUpdates) {
                        if (!success) {
                            hasFailed[0] = true; // Mark as failed if any update fails
                        }
                        pendingUpdates[0]--;
                        // If all updates are done
                        if (pendingUpdates[0] == 0) {
                            callback.onResult(!hasFailed[0]); // Success if no failures occurred
                        }
                    }
                });
            }
        });
    }

    private void addDining(
            String key, String username,
            Callback<Boolean> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(username).child("dining");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> value = new ArrayList<>();

                if (dataSnapshot.exists()) {
                    // Parse the raw data into a list
                    for (DataSnapshot child : dataSnapshot.getChildren()) {
                        String diningKey = child.getValue(String.class);
                        if (diningKey != null) {
                            value.add(diningKey);
                        }
                    }
                }

                // Check if the key is already in the list
                if (!value.contains(key)) {
                    value.add(key); // Add the new key if it's not already in the list
                }

                // Update the dining list in Firebase
                ref.setValue(value).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onResult(true); // Success
                    } else {
                        callback.onResult(false); // Failure
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    public void getDining(
            Callback<ArrayList<String>> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(this.usernameCurr).child("dining");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    callback.onResult(null);
                    return;
                }

                ArrayList<String> diningList = new ArrayList<>();
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    String diningId = child.getValue(String.class);
                    if (diningId != null) {
                        diningList.add(diningId);
                    }
                }
                callback.onResult(diningList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(null);
            }
        });
    }

    public void addAccommodation(
            String key,
            Callback<Boolean> callback
    ) {
        this.getCollaborator(collaborator -> {
            // Prepare a list of users to update
            ArrayList<String> usersToUpdate;
            if (collaborator == null) {
                usersToUpdate = new ArrayList<>();
            } else {
                usersToUpdate = new ArrayList<>(collaborator);
            }
            usersToUpdate.add(this.usernameCurr);

            // Update accommodation list for all users in the list
            int[] pendingUpdates = {usersToUpdate.size()};
            boolean[] hasFailed = {false};
            for (String username : usersToUpdate) {
                addAccommodation(key, username, success -> {
                    synchronized (pendingUpdates) {
                        if (!success) {
                            hasFailed[0] = true; // Mark as failed if any update fails
                        }
                        pendingUpdates[0]--;
                        // If all updates are done
                        if (pendingUpdates[0] == 0) {
                            callback.onResult(!hasFailed[0]); // Success if no failures occurred
                        }
                    }
                });
            }
        });
    }

    private void addAccommodation(
            String key, String username,
            Callback<Boolean> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(username).child("accommodation");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> value = new ArrayList<>();

                if (dataSnapshot.exists()) {
                    // Parse the raw data into a list
                    for (DataSnapshot child : dataSnapshot.getChildren()) {
                        String accoKey = child.getValue(String.class);
                        if (accoKey != null) {
                            value.add(accoKey);
                        }
                    }
                }

                // Check if the key is already in the list
                if (!value.contains(key)) {
                    value.add(key); // Add the new key if it's not already in the list
                }

                // Update the accommodations list in Firebase
                ref.setValue(value).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onResult(true); // Success
                    } else {
                        callback.onResult(false); // Failure
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    public void getAccommodation(
            Callback<ArrayList<String>> callback
    ) {
        DatabaseReference ref = this.userDatabase.child(this.usernameCurr).child("accommodation");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    callback.onResult(null);
                    return;
                }

                ArrayList<String> accoList = new ArrayList<>();
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    String accoId = child.getValue(String.class);
                    if (accoId != null) {
                        accoList.add(accoId);
                    }
                }
                callback.onResult(accoList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(null);
            }
        });
    }

    public void addTravel(
            String key,
            Callback<Boolean> callback
    ) {
        // Reference to the current user's travel list in the database
        DatabaseReference ref = this.userDatabase.child(this.usernameCurr).child("travel");

        // Retrieve the existing travel list
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> travelKeys = new ArrayList<>();

                // If travel data exists, populate the list
                if (dataSnapshot.exists()) {
                    for (DataSnapshot child : dataSnapshot.getChildren()) {
                        String travelKey = child.getValue(String.class);
                        if (travelKey != null) {
                            travelKeys.add(travelKey);
                        }
                    }
                }

                // Add the new key if it's not already in the list
                if (!travelKeys.contains(key)) {
                    travelKeys.add(key);
                }

                // Update the travel list in Firebase
                ref.setValue(travelKeys).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onResult(true); // Success
                    } else {
                        callback.onResult(false); // Failure
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    /* Getter */

    public String getUsernameCurr() {
        return usernameCurr;
    }

    /* Callbacks */

    public interface Callback<T> {
        void onResult(T callback);
    }
    public void addBooking(String key, Callback<Boolean> callback) {
        // Implementation for adding a booking key to the user's booking list
        boolean success = true; // Replace with actual logic to add the booking key
        callback.onResult(success);
    }

    public void getBooking(Callback<ArrayList<String>> callback) {
        // Implementation for fetching the user's booking keys
        ArrayList<String> keys = new ArrayList<>(); // Replace with actual logic to fetch booking keys
        callback.onResult(keys);
    }

}
