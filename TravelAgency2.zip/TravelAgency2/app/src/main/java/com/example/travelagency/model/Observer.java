package com.example.travelagency.model;

public interface Observer {
    void onUpdate(String eventType, Object data);
}